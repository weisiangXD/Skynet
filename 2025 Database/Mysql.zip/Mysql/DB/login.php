<?php

session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = ""; 

// === 修正 1：將 $display_role 定義在 GET/POST 判斷之外 (讓頁面首次載入時也能正常顯示) ===
$display_role = "Guest"; // 預設身份為訪客
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // 如果 Session 顯示已登入，則顯示儲存的身份和名稱
    $display_role = $_SESSION['role'] . ": " . $_SESSION['username'];
}
// ===================================================================================

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 資料庫連線 (保持不變)
    $conn = new mysqli("localhost", "root", "111803", "2025dbproject");

    if ($conn->connect_error) {
        die("資料庫連線失敗: " . $conn->connect_error);
    }

    // 硬編碼的帳號密碼 (保持不變)
    $admin_user = "admin";
    $admin_pass = "123";

    // 接收表單資料 (保持不變)
    $username = isset($_POST["username"]) ? $_POST["username"] : "";
    $password = isset($_POST["password"]) ? $_POST["password"] : "";


    // 驗證邏輯
    if ($username == $admin_user && $password == $admin_pass) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = 'Admin'; 
        $message = "登入成功！";
        
        // === 修正 2：登入成功後，更新 $display_role，這樣不需要重新載入頁面也會立刻改變 ===
        $display_role = $_SESSION['role'];
        // ==============================================================================
        
    } else {
        $message = "帳號或密碼錯誤，請重試。";
    }
    
    // 關閉資料庫連線 (保持不變)
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    <style>
    :root{
      --bColor: rgba(0, 0, 0, 0.712);
      font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    }

    .user-status{
    position: absolute; 
    top: 25px;        
    right: 20px;       
    color: yellow;      
    font-size: 110%;
    font-weight: bold;
    z-index: 10;      
}

    .top_container{
      padding-left: 20px;
      padding-top: 20px;
    }

    .Top_button{
      background-color: var(--bColor);
      font-size: 100%;
      color: rgb(255, 255, 255);
      padding: 10px 15px;
      border-color: rgb(0, 0, 0);
      cursor: pointer;
      border-radius: 10px;
      display: inline-block;
      text-decoration: none;
      transition: all 0.3s ease-in-out;
    }

    .Top_button:hover{
      background-color: rgb(255, 249, 249);
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
      color: rgb(0, 0, 0);
      transform: scale(0.9);
    }

    .background{
      background-color: rgba(0, 0, 0, 0.836);
      filter:blur(5px);
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      position: fixed;
      top:  0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: -1;
    }
    body{
      margin: 0;
    }

    .login-form {
        width: 300px; 
        margin: 50px auto; 
        padding: 20px;
        border: 1px solid white; 
        border-radius: 10px;
    }

    .input-row {
        display: flex;            
        justify-content: space-between; 
        align-items: center;       
        margin-bottom: 10px;  
        color:white;
        text-align: center;  
        padding: 10px;
    }  

    .input-row label {
        flex-basis: 120px; 
        padding-right: 10px;
    }

    .input-row input {
        flex-grow: 1; 
    }

    .submit{
        text-align: center;
        margin-top: 10px;
    }
    .submit_button{
        width: 100%;
        padding: 5px;
        background-color: white;
        color: black;
        border-radius: 5px;
        cursor: pointer;
    }
    
    
    .message-box {
        text-align: center;
        color: yellow;
        font-weight: bold;
        margin-top: 20px;
    }
    </style>
</head>
<body>

<div class="user-status">
    <?php echo $display_role; ?>
</div>
<div class="login-page-container"></div>

<div class="top_container">
  <a href="homepage.php" class="Top_button">Home</a>
  <span class="board-separator">|</span>
  
  <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <a href="logout.php" class="Top_button">Logout</a>
    <span class="board-separator">|</span>
  <?php else: ?>
    <a href="login.php" class="Top_button">Login</a>
    <span class="board-separator">|</span>
  <?php endif; ?>
  
  <a href="datapage.php" class="Top_button">Data</a>
  <span class="board-separator">|</span>
  <a href="contactpage.php" class="Top_button">Contact us</a>
</div>
<hr/>
<div class="background"></div>

<div class="login-page-container">
    
    <form action="" method="POST" class="login-form">
        <div class="input-row">
            <label for="username">Username :</label>
            <input type="text" id="username" name="username" required>
        </div>
        
        <div class="input-row">
            <label for="password">Password :</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="submit">
            <button type="submit" class="submit_button">Submit</button>  
        </div>

        <?php if (!empty($message)): ?>
            <div class="message-box">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

    </form>
    
</div>
</body>

</html>