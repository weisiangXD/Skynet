<?php
session_start();
$display_role = "Guest"; // 預設身份為訪客
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // 如果 Session 顯示已登入，則顯示儲存的身份和名稱
    $display_role = $_SESSION['role'];
}
?>

<!DOCTYPE html>
<html lang="zh-TW">

<!--    CSS     -->
<style>
:root{
  --bColor: rgba(0, 0, 0, 0.712);
  font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif
}

.top_container{
  padding-left: 20px;
  padding-top: 20px;
}

.Top_button{
  background-color: var(--bColor);
  font-size: 100%;
  color: rgb(255, 255, 255);
  padding: 10px 15px;
  border-color: rgb(0, 0, 0);
  cursor: pointer;
  border-radius: 10px;
  display: inline-block;
  text-decoration: none;
  transition: all 0.3s ease-in-out;
  
}

.Top_button:hover{
  background-color: rgb(255, 249, 249);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  color: rgb(0, 0, 0);
  transform: scale(0.9);
  
}

.Homepage_IMG{
  display: block ;
  width: 45%;
  margin: 4% auto 0 auto;
  border-radius: 20px;
  
}

.background{
  background-color: rgba(0, 0, 0, 0.836);
  filter:blur(5px);
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  position: fixed;

  top:  0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: -1;
}
body{
  margin: 0;
}

.font_color{
  text-align: center;
  margin-top: auto;
  margin-bottom: auto;
  color:rgb(236, 236, 236);
  text-shadow: 5px 10px 10px #000000;
}

.user-status{
    position: absolute; 
    top: 25px;        
    right: 20px;       
    color: yellow;      
    font-size: 110%;
    font-weight: bold;
    z-index: 10;      
}

</style>

<meta charset="UTF-8">
<!--    Top     -->
<div class="user-status">
<?php echo $display_role; ?>
</div>
<div class="top_container">
  <a href="homepage.php" class="Top_button">Home</a>
  <span class="board-separator">|</span>
  
  <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <a href="logout.php" class="Top_button">Logout</a>
    <span class="board-separator">|</span>
  <?php else: ?>
    <a href="login.php" class="Top_button">Login</a>
    <span class="board-separator">|</span>
  <?php endif; ?>
  
  <a href="datapage.php" class="Top_button">Data</a>
  <span class="board-separator">|</span>
  <a href="contactpage.php" class="Top_button">Contact us</a>
</div>
<hr/>

<img class="Homepage_IMG" src="Homepage.jpeg">
<div class="background"></div>
<h1 class="font_color">2025硬體大調查</h1>
<br/><br/>





</html>