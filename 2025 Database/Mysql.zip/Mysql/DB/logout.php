<?php
// 1. 啟動 Session，這樣才能存取和清除它
session_start();

// 2. 清除所有的 Session 變數
$_SESSION = array();

// 3. 徹底銷毀 Session
session_destroy();

// 4. 將用戶導向到登入頁面 (或首頁)
// header() 函數必須在任何 HTML 內容輸出前使用！
header("Location: login.php");
exit; // 確保導向後程式停止執行
?>