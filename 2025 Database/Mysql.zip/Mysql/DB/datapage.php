<?php
session_start();

$display_role = "Guest";
if (!empty($_SESSION['logged_in'])) {
    $display_role = $_SESSION['role'];
}

$conn = mysqli_connect('localhost','root','111803','2025dbproject');
if (!$conn) {
    die("DB connection failed: " . mysqli_connect_error());
}

   


$result = mysqli_query($conn, $sql);
if (!$result) {
    die("SQL Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<!--    CSS     -->
<style>
:root{
  --bColor: rgba(0, 0, 0, 0.712);
  font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif
}

.top_container{
  padding-left: 20px;
  padding-top: 20px;
}

.Top_button{
  background-color: var(--bColor);
  font-size: 100%;
  color: rgb(255, 255, 255);
  padding: 10px 15px;
  border-color: rgb(0, 0, 0);
  cursor: pointer;
  border-radius: 10px;
  display: inline-block;
  text-decoration: none;
  transition: all 0.3s ease-in-out;
  
}

.Top_button:hover{
  background-color: rgb(255, 249, 249);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  color: rgb(0, 0, 0);
  transform: scale(0.9);
  
}

.background{
  background-color: rgba(0, 0, 0, 0.836);
  filter:blur(5px);
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  position: fixed;

  top:  0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: -1;
}
body{
  margin: 0;
}

.user-status{
    position: absolute; 
    top: 25px;        
    right: 20px;       
    color: yellow;      
    font-size: 110%;
    font-weight: bold;
    z-index: 10;      
}

</style>

<!--    Top     -->
<div class="user-status">
<?php echo $display_role; ?>
</div>
<div class="top_container">
  <a href="homepage.php" class="Top_button">Home</a>
  <span class="board-separator">|</span>
  
  <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <a href="logout.php" class="Top_button">Logout</a>
    <span class="board-separator">|</span>
  <?php else: ?>
    <a href="login.php" class="Top_button">Login</a>
    <span class="board-separator">|</span>
  <?php endif; ?>
  
  <a href="datapage.php" class="Top_button">Data</a>
  <span class="board-separator">|</span>
  <a href="contactpage.php" class="Top_button">Contact us</a>
</div>
<div style="padding:40px; color:white;">
  <h2>Hardware Data</h2>

  <table border="1" cellpadding="10" cellspacing="0">
    <tr>
      <th>Model</th>
      <th>Type</th>
      <th>Price</th>
      <th>Feedback</th>
      <th>Manufacturer</th>
      <th>Country</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?= htmlspecialchars($row['model']) ?></td>
      <td><?= htmlspecialchars($row['type']) ?></td>
      <td><?= htmlspecialchars($row['price']) ?></td>
      <td><?= htmlspecialchars($row['feedback']) ?></td>
      <td><?= htmlspecialchars($row['manufacturer_name']) ?></td>
      <td><?= htmlspecialchars($row['country']) ?></td>
    </tr>
    <?php endwhile; ?>

  </table>
</div>
<hr/>
<div class="background"></div>
<!--            -->


</html>